// Complete as funções com os tipos apropriados

function soma(a, b) {
    return a + b;
}

function concatenaPalavras(palavra1, palavra2) {
    return palavra1.concat(palavra2)
}

function tamanhoDoVetor(vetor) {
    return vetor.length;
}
