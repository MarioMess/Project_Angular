// Crie um novo tipo "StringOuNumero" utilizando união de tipo

export type StringOuNumero = any;
