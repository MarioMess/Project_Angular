export interface Pessoa {
    nome: string;
    idade: number;
}

export type Pessoa2 = {
    nome: string;
    idade: number;
}
