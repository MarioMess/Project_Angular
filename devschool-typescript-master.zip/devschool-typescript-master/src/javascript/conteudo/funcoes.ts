function funcaoComNome() {
    return 0;
}

// funcoes anonimas podem ser atribuidas a variáveis
const funcao = function () {
    return 1;
}

// funcoes anonimas (em formato arrow-function) podem ser atribuidas a variáveis
const arrowFn = () => {
    const a = 5;

    () => {
        a
    }
}


