function switchTest(switchVar: string) {
    switch (switchVar) {
        case 'case1': {
            console.log('case1');
            break;
        }
        case 'case2': {
            console.log('case2');
            break;
        }
        default: {
            console.log('default');
        }
    }
}
