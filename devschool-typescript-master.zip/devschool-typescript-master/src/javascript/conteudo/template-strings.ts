const minhaTemplateString = `minha string`;

const templateStringInterpolada = `interpolada: ${minhaTemplateString}`
